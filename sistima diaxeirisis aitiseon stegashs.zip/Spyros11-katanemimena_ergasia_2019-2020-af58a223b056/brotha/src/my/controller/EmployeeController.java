package my.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import my.dao.EmployeeDAO;
import my.dao.InternalUserDAO;
import my.dao.InternalUserDAOImpl;
import my.dao.StudentDAO;
import my.db.DbConnection;
import my.db.DbOperate;
import my.intranet.Employee;
import my.intranet.InternalUser;
import my.intranet.Student;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeDAO empDAO;
	
	@Autowired
	private InternalUserDAO userDAO;
	
	@Autowired
	private StudentDAO stdDAO;
	Employee emp = new Employee(null, null, 0, null, false, 0);
	
	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public String employeePage(HttpServletRequest request, Model model) {
		
		return "employee";
	}
	
	
	@RequestMapping(value = "/evaluateStatement", method = RequestMethod.GET)
	public String evStatement(@ModelAttribute("user") InternalUser user, @ModelAttribute("student") Student student,HttpServletRequest request, Model model, HttpSession session) {
		int internalUsersId = Integer.parseInt(request.getParameter("id"));

		// find student through id
		student = stdDAO.getStudent(internalUsersId);

		boolean city = Boolean.parseBoolean(request.getParameter("city"));
		double accessYear = Double.parseDouble(request.getParameter("accessYear"));
		boolean valid = emp.evaluateStatement(city, accessYear);
		if(valid == true) {
			JOptionPane.showMessageDialog(null,"Request valid");

		}else {
			JOptionPane.showMessageDialog(null,"Request not valid");
			
		}
		System.out.println(city);
		return "student";
	}
	@RequestMapping(value = "/rateStatement", method = RequestMethod.GET)
	public String rateStatement(@ModelAttribute("user") InternalUser user, @ModelAttribute("student") Student student,HttpServletRequest request, Model model, HttpSession session) {
		
		// get info from form
		int internalUsersId = Integer.parseInt(request.getParameter("id"));
	
		user = userDAO.getUser(internalUsersId);
		boolean isActivated = user.isActivated(); 

		double studentsIncome = Double.parseDouble(request.getParameter("studentsIncome"));
		boolean parentsEmployment = Boolean.parseBoolean(request.getParameter("parentsEmployment"));
		double familyIncome = Double.parseDouble(request.getParameter("familyIncome"));
		int siblings = Integer.parseInt(request.getParameter("siblings"));
		int freeHousingYears = Integer.parseInt(request.getParameter("freeHousingYears"));
		
		boolean city = Boolean.parseBoolean(request.getParameter("city"));
		double accessYear = Double.parseDouble(request.getParameter("accessYear"));
		boolean valid = emp.evaluateStatement(city, accessYear);
		if(valid == true) {
			JOptionPane.showMessageDialog(null,"Request valid");

		}else {
			JOptionPane.showMessageDialog(null,"Request not valid");
			return "redirect:/student";
		}
		
		int points = emp.rateStudentCriteria(internalUsersId, isActivated, studentsIncome, parentsEmployment, familyIncome, siblings, freeHousingYears, city);
		// store the points between sessions
		session.setAttribute("points", points);
		return "user";
	}
	
}
