package my.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import my.dao.InternalUserDAO;
import my.intranet.InternalUser;

@Controller
public class HomeController {

	// view home page
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String welcomePage() {
		return "home";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login() {
		return "login";
	}

	@RequestMapping(value = "/addForm", method = RequestMethod.GET)
	public String addForm(Model model) {
		return "addForm";
	}
	
	@RequestMapping(value = "/addStForm", method = RequestMethod.GET)
	public String addStudentForm(Model model) {
		return "addStForm";
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutPage() {
		return "login";
	}
	
	
	@RequestMapping(value = "/idForm", method = RequestMethod.GET)
	public String idForm(Model model) {
		return "idForm";
	}
	
	@RequestMapping(value = "/updateForm", method = RequestMethod.GET)
	public String updateForm(Model model) {
		return "updateForm";
	}
	
	@RequestMapping(value = "/help_home", method = RequestMethod.GET)
	public String help_home() {
		return "help_home";
	}
	@RequestMapping(value = "/facilities", method = RequestMethod.GET)
	public String facilities() {
		return "facilities";
	}
	@RequestMapping(value = "/contact_us", method = RequestMethod.GET)
	public String contact_us() {
		return "contact_us";
	}
	
	
	
}
