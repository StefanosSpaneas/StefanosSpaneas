package my.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import my.dao.EmployeeDAO;
import my.dao.InternalUserDAO;
import my.dao.InternalUserDAOImpl;
import my.dao.StudentDAO;
import my.db.DbOperate;
import my.intranet.InternalUser;
import my.intranet.Student;
import my.settings.Strings;

@Controller
public class StudentController {
	@Autowired
	private EmployeeDAO empDAO;
	
	@Autowired
	private InternalUserDAO userDAO;
	
	@Autowired
	private StudentDAO stdDAO;
	
	@RequestMapping(value = "/student", method = RequestMethod.GET)
	public String studentPage() {
		return "student";
	}
	
	@RequestMapping(value = "/viewStudent", method = RequestMethod.POST)
	public String studentsPage(@ModelAttribute("student") Student student, HttpServletRequest request, Model model, HttpSession session) {
		
		int id = Integer.parseInt(request.getParameter("id"));

		return "students-list";
	}
	
	@RequestMapping(value = "/saveStudent", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute("user") InternalUser user, @ModelAttribute("student") Student student, HttpServletRequest request, Model model) {
		// save data from form
		int departure = Integer.parseInt(request.getParameter("departure"));
		double accessYear = Double.parseDouble(request.getParameter("accessYear"));
		double studentsIncome = Double.parseDouble(request.getParameter("studentsIncome"));
		boolean parentsEmployment = Boolean.parseBoolean(request.getParameter("parentsEmployment"));
		double familyIncome = Double.parseDouble(request.getParameter("familyIncome"));
		int siblings = Integer.parseInt(request.getParameter("siblings"));
		boolean city = Boolean.parseBoolean(request.getParameter("city"));
		int internalUsersId = Integer.parseInt(request.getParameter("internalUsersId"));
		
		user.setId(internalUsersId);
		student.setUser(user);
		
		System.out.println(departure+" "+accessYear+" "+studentsIncome+" "+parentsEmployment+" "+familyIncome+" "+siblings+" "+city+" "+internalUsersId);

		// save dao object
		stdDAO.saveStudent(student);
		
		return "admin";
	}
	InternalUserDAOImpl user =  new InternalUserDAOImpl();

	@RequestMapping(value = "/activateStudent", method = RequestMethod.GET)
	public String activateStudent(@ModelAttribute("user") InternalUser user,HttpServletRequest request, Model model, HttpSession session) {
		int id = (Integer) session.getAttribute("id");
		System.out.println(id);
		
		user.setId(id);
		
		//find user through id
		user = userDAO.getUser(user.getId());			

		if(user == null) {
			String referrer = request.getHeader("referer");
			JOptionPane.showMessageDialog(null,"NO such id");
			return "redirect:/idForm";
		}
		if(user.isActivated() == false)
			user.setActivated(true);
		else
			JOptionPane.showMessageDialog(null,"User is already activated");
		
		model.addAttribute("id", user.getId());
		model.addAttribute("user", user);

		System.out.println(user.isActivated());
		//update method
		DbOperate.update(id, user.getFirstName(), user.getLastName(), user.getEmail(), user.isActivated());
		
		return "user";
	}
	
	@RequestMapping(value = "/viewStudent", method = RequestMethod.GET)
	public String viewStudent(@ModelAttribute("student") Student st, @ModelAttribute("user") InternalUser user, HttpServletRequest request, Model model, HttpSession session) {
		int id = (Integer) session.getAttribute("id");
		
		st.setId(id);
		st = stdDAO.getStudent(id);
		// get users from dao

		if(st == null) {
			String referrer = request.getHeader("referer");
			JOptionPane.showMessageDialog(null,"NO suck id");
			return "redirect:/idForm";
		}
			
				
		// add the users to the model
		model.addAttribute("student", st);
		model.addAttribute("id", id);
		
		return "students-list";		
	}
	
	@RequestMapping(value = "/students", method = RequestMethod.GET)
	public String playPage(Model model) {

		// get users from dao
		List<Student> students = stdDAO.getStudents();
		if(students.isEmpty())
			System.out.println("I am empty");
		System.out.println("hi");

		// add the customers to the model
		model.addAttribute("students", students);

		return "students-list";
	}
	
	// make residence req
	@RequestMapping(value = "/residenceReq", method = RequestMethod.GET)
	public String residenceReq(@ModelAttribute("student") Student student, @ModelAttribute("user") InternalUser user, HttpServletRequest request, Model model, HttpSession session) {
		int internalUsersId = (Integer)session.getAttribute("id");

		user = userDAO.getUser(internalUsersId);
		// user needs to be activated first
		boolean isActivated = user.isActivated();
		
		if(user.isActivated() == false) {
			JOptionPane.showMessageDialog(null,"You are not activated please contact an employee");
			return "redirect:/student";

		}

		System.out.println(user.getId());
		JOptionPane.showMessageDialog(null,"Request sent!!");
		
		return "student";
	}
	
	@RequestMapping(value = "/changeInfo", method = RequestMethod.GET)
	public String changeMail(@ModelAttribute("user") InternalUser user,HttpServletRequest request, Model model, HttpSession session) {
		int id = (Integer)session.getAttribute("id");

		user.setId(id);
		System.out.println(id);

		Strings strings = new Strings();
		boolean input = false;
		String newMail;
		do {
			newMail = JOptionPane.showInputDialog(null, "Type the new mail please");
			if(strings.checkMail(newMail) == true)
				input = true;
		}while(input = false);	
		user = userDAO.getUser(user.getId());			

		user.set�mail(newMail);
		
		model.addAttribute("user", user);
		// update status method
		DbOperate.update(id, user.getFirstName(), user.getLastName(), user.getEmail(), user.isActivated());

		return "user";
	}
	
}
