package my.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import my.dao.InternalUserDAO;
import my.dao.InternalUserDAOImpl;
import my.db.DbOperate;
import my.intranet.InternalUser;
import my.settings.Strings;

@Controller
public class UserController {

	Strings strings = new Strings();
	
	@RequestMapping(value = "/method", method = RequestMethod.GET)
	public String methodPage() {
		return "method";
	}

	@Autowired
	private InternalUserDAO userDAO;

	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String playPage(Model model) {

		// get users from dao
		List<InternalUser> users = userDAO.getInternalUsers();

		// add the customers to the model
		model.addAttribute("users", users);

		return "user";
	}

	@RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute("user") InternalUser user,HttpServletRequest request, Model model) {
		// save the user using the service
		
		model.addAttribute("firstName", user.getFirstName());
		model.addAttribute("lastName", user.getLastName());
		// check for correct input
		String email = request.getParameter("mail");
		if(strings.checkMail(email) == false) {
			JOptionPane.showMessageDialog(null,"NOT valid email");

			return "redirect:/addForm";

		}
		user.set�mail(email);
		
		model.addAttribute("mail", user.getEmail());

		userDAO.saveUser(user);

		return "employee";
	}

	@RequestMapping(value = "/deleteUser", method = RequestMethod.POST)
	public String deleteUser(@ModelAttribute("user") InternalUser user,HttpServletRequest request, Model model, HttpSession session) {
		int id = (Integer)session.getAttribute("id");
		// the id i want to start again
		//int id = 47;
		// get users from dao
		user.setId(id);
		user = userDAO.getUser(user.getId());			
		if(user == null) {
			String referrer = request.getHeader("referer");
			JOptionPane.showMessageDialog(null,"NO suck id");
			return "redirect:/idForm";
		}	
		// save the customer using the service
		model.addAttribute("id", user.getId());

		userDAO.deleteUser(user.getId());
		JOptionPane.showMessageDialog(null,"User deleted");

		return "user";
	}
	
	List<InternalUser> users = null;
	InternalUserDAOImpl user =  new InternalUserDAOImpl();
	
	@RequestMapping(value = "/viewUser", method = RequestMethod.POST)
	public String viewUser(@ModelAttribute("user") InternalUser user, HttpServletRequest request, Model model, HttpSession session) {
		int id = Integer.parseInt(request.getParameter("id"));
		//Session currentSession = sessionFactory.getCurrentSession();
		//session.setAttribute("id",id);
		
		// get users from dao
		user.setId(id);
		user = userDAO.getUser(user.getId());			
		if(user == null) {
			String referrer = request.getHeader("referer");
			JOptionPane.showMessageDialog(null,"NO suck id");
			return "redirect:/idForm";
		}		
				
		// add the users to the model
		model.addAttribute("user", user);
		session.setAttribute("id",id);
		
		return "user";
	}
	
	@RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	public String updateUser(@ModelAttribute("user") InternalUser user,HttpServletRequest request, Model model, HttpSession session) {

		// take input from the from updateForm
		model.addAttribute("firstName", user.getFirstName());
		model.addAttribute("lastName", user.getLastName());

		int id = (Integer)session.getAttribute("id");
		System.out.println(id);
	
		user.setId(id);
		
		// check for correct input
		String email = request.getParameter("mail");
		if(strings.checkMail(email) == false) {
			JOptionPane.showMessageDialog(null,"NOT valid email");

			return "redirect:/updateForm";

		}
		user.set�mail(email);
		
		model.addAttribute("mail", user.getEmail());		
		model.addAttribute("user", user);
		
		DbOperate.update(id, user.getFirstName(), user.getLastName(), user.getEmail(), user.isActivated());
		
		return "user";
	}
	
	
}
