package my.dao;

import java.util.List;

import my.intranet.InternalUser;
import my.intranet.Student;

public interface EmployeeDAO {

	/*
	List<Student> getStudents();
	void saveStudent(Student st);
	public Student getStudent(InternalUser user);
	*/

}
