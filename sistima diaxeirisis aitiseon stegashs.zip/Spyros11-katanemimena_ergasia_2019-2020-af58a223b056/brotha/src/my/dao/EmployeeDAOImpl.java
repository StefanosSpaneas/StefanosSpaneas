package my.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import my.intranet.InternalUser;
import my.intranet.Student;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO{

}
