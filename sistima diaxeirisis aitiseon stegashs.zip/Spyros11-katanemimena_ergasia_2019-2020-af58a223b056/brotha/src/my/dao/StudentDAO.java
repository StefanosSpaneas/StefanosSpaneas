package my.dao;

import java.util.List;

import my.intranet.Student;

public interface StudentDAO {

	public void changeContactInfo();
	public int viewRank();
	public void checkResidenceRequest();
	public void residenceRequest();

	List<Student> getStudents();
	void saveStudent(Student st);
	public Student getStudent(int id);
}
