package my.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import my.intranet.InternalUser;
import my.intranet.Student;

@Repository
public class InternalUserDAOImpl implements InternalUserDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	@Transactional
	public List<InternalUser> getInternalUsers() {
		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// create a query
		Query<InternalUser> query = currentSession.createQuery("from internal_users", InternalUser.class);
		//Query<InternalUser> query = currentSession.createQuery("SELECT * FROM internal_users", InternalUser.class);

		// execute the query and get the results list
		List<InternalUser> users = query.getResultList();

		// return the results
		return users;
	}
	
	@Override
	@Transactional
	public void saveUser(InternalUser user) {
		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		if (user.getId() != 0) {
			// update the student
			currentSession.update(user);
		} else {
			// save the student
			currentSession.save(user);
		}

	}
	
	@Override
	@Transactional
	public InternalUser getUser(int id) {

		Session currentSession = sessionFactory.getCurrentSession();

		InternalUser user = currentSession.get(InternalUser.class, id);
		return user;
	}

	@Override
	@Transactional
	public void deleteUser(int id) {

		Session currentSession = sessionFactory.getCurrentSession();

		InternalUser user = currentSession.get(InternalUser.class, id);

		currentSession.delete(user);

	}
}
