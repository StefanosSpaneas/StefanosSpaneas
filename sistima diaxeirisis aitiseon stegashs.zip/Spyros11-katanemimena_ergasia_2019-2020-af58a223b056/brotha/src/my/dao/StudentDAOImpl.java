package my.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import my.intranet.InternalUser;
import my.intranet.Student;

@Repository
public class StudentDAOImpl implements StudentDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void changeContactInfo() {
		// needs the update method but for the specific column
		
		
	}

	@Override
	public int viewRank() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void checkResidenceRequest() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void residenceRequest() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	@Transactional
	public List<Student> getStudents() {
		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// create a query
		Query<Student> query = currentSession.createQuery("from students", Student.class);

		// execute the query and get the results list
		List<Student> students = query.getResultList();
		if(students.isEmpty())
			System.out.println("I am empty");

		// return the results
		return students;
	}
	
	@Override
	@Transactional
	public void saveStudent(Student st) {
		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		if (st.getId() != 0) {
			// update the student
			currentSession.update(st);
		} else {
			// save the student
			currentSession.save(st);
		}

	}

	@Override
	@Transactional
	public Student getStudent(int id) {

		Session currentSession = sessionFactory.getCurrentSession();
		//int id = student.getId();
		System.out.println(id+"-------");
		Student student = currentSession.get(Student.class, id);
		return student;
	}


}
