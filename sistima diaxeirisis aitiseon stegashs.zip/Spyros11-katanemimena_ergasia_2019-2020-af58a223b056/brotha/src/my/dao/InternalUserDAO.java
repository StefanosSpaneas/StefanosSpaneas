package my.dao;

import java.util.List;

import my.intranet.InternalUser;
import my.intranet.Student;

public interface InternalUserDAO {

	public List<InternalUser> getInternalUsers();
	public void saveUser(InternalUser user);
	public void deleteUser(int id);
	public InternalUser getUser(int id);
}
