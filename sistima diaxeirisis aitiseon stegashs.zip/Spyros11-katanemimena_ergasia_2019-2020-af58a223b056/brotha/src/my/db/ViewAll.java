package my.db;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import my.intranet.InternalUser;
import my.intranet.Student;

public class ViewAll {

	 public static void main(String[] args) {

         // create session factory
         SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(InternalUser.class).addAnnotatedClass(InternalUser.class)
                         .buildSessionFactory();

         // create session
         Session session = factory.getCurrentSession();

         try {
                 // start a transaction
                 session.beginTransaction();

                 // query students
                 List<InternalUser> users = session.createQuery("from internal_users").getResultList();
                 List<Student> students = session.createQuery("from students").getResultList();

                 System.out.println("all users");
                 //displayUsers(users);
                 displayStudents(students);
                 
                 /*
                 // query students: lastName='��������'
                 users = session.createQuery("from internal_users u where u.lastName='haba'").getResultList();
                 System.out.println("users: lastName='haba'");
                 displayUsers(users);

                 
                 // query students: lastName='��������' OR firstName='�������'
                 users = session.createQuery("from internal_users u where u.lastName='haba'" + " OR u.firstName='hibi'")
                                 .getResultList();
                 System.out.println("users: lastName='��������' OR firstName='�������'");
                 displayUsers(users);

                 // query students where email ends with hua.gr
                 users = session.createQuery("from internal_users s where s.mail LIKE '%hua.gr'").getResultList();
                 System.out.println("users where email LIKE '%hua.gr'");
                 displayUsers(users);

				*/
                 // commit transaction
                 session.getTransaction().commit();

                 System.out.println("Done!");

         } finally {
                 factory.close();
         }

	 }

	 private static void displayUsers(List<InternalUser> users) {
	         // display students
	         for (InternalUser user : users) {
	                 System.out.println(user.getFirstName() +"\t" +user.getLastName() +"\t" +user.getEmail()+"\t" +user.getId());
	         }
	 }
	 private static void displayStudents(List<Student> students) {
	     // display students
	     for (Student student : students) {
	             System.out.println(student.getFirstName() +"\t" +student.getLastName() +"\t" +student.getEmail()+"\t" +student.getId()+"\t" +student.getDeparture() +"\t" +student.getAccessYear()+"\t" +student.getStudentsIncome()+"\t" +student.getFamilyIncome()+"\t" +student.getParentsEmployement()+"\t" +student.getFamilyIncome()+"\t"
	            		 +student.getSiblings() +"\t" +student.getCity());
	     }
	}
 
}
