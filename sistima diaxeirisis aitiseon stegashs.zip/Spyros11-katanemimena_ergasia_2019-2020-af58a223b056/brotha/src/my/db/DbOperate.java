package my.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import javax.swing.JOptionPane;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import my.intranet.InternalUser;
import my.intranet.Student;

public class DbOperate {

	Student std1 = new Student();
	InternalUser user1 = new InternalUser();
	
	public static void main(String[] args) {

		//test();
		viewAll();
		//update(1);
	}

	public static void test() {
		// create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(InternalUser.class).addAnnotatedClass(Student.class) // kati paizei edw
				.buildSessionFactory();

		// create session
		Session session = factory.getCurrentSession();

		try {
			// create the student object
			InternalUser u2 = new InternalUser("haba", "haba", 10, "hibi@hua.gr", true);
			Student student = new Student("haba", "haba", 1, "hibi@hua.gr", true, 2, 3, 4, true, 8, 1, true);
			student.setUser(u2);
			student.setFirstName("sp");
			// start a transaction
			session.beginTransaction();

			// save the student object
			//session.save(u2);
			session.save(student);

			// commit transaction
			session.getTransaction().commit();
			System.out.println("Done!");

		} finally {
			factory.close();
		}
	}

	public static void viewAll() {
		// create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(InternalUser.class).addAnnotatedClass(Student.class).buildSessionFactory();

		// create session
		Session session = factory.getCurrentSession();

		try {
			// start a transaction
			session.beginTransaction();
			
			// query students
			List<InternalUser> users = session.createQuery("from internal_users").getResultList();
			if(users.isEmpty())
				System.out.println("I am empty");
			
			//displayUsers(users);
			
			List<Student> students = session.createQuery("from students").getResultList();
			if(students.isEmpty())
				System.out.println("I am empty");
			
			displayStudents(students);

			/*
			 * // query students: lastName='��������' users =
			 * session.createQuery("from internal_users u where u.lastName='haba'").
			 * getResultList(); System.out.println("users: lastName='haba'");
			 * displayUsers(users);
			 * 
			 * 
			 * // query students: lastName='��������' OR firstName='�������' users =
			 * session.createQuery("from internal_users u where u.lastName='haba'" +
			 * " OR u.firstName='hibi'") .getResultList();
			 * System.out.println("users: lastName='��������' OR firstName='�������'");
			 * displayUsers(users);
			 * 
			 * // query students where email ends with hua.gr users =
			 * session.createQuery("from internal_users s where s.mail LIKE '%hua.gr'").
			 * getResultList(); System.out.println("users where email LIKE '%hua.gr'");
			 * displayUsers(users);
			 * 
			 */
			// commit transaction
			session.getTransaction().commit();

			System.out.println("Done!");

		} finally {
			factory.close();
		}

	}

	public static void update(int id, String firstName, String lastName, String mail, boolean isActivated) {
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Student.class)
				.addAnnotatedClass(InternalUser.class).buildSessionFactory();

		// create session
		Session session = factory.getCurrentSession();

		// needs a scanner to enter the id
		try {

			session = factory.getCurrentSession();
			// start a transaction
			session.beginTransaction();

			// retrieve user with id = 1
			System.out.println("retrieving internal_user with id = " +id);
			InternalUser user = session.get(InternalUser.class, id);

			// update internal user email
			System.out.println("updating internal user's email");
			user.setFirstName(firstName);
			System.out.println(firstName+"-------");
			user.setLastName(lastName);
			user.setActivated(isActivated);
			user.set�mail(mail);

			// commit transaction
			session.getTransaction().commit();

			
			// ---------------------------
			/*
			session = factory.getCurrentSession();
			session.beginTransaction();

			// update email for user with lastName='haba'
			session.createQuery("update internal_users set mail='hibi@hua.gr' where lastName='haba'").executeUpdate();

			session.getTransaction().commit();
			*/
			
			System.out.println("Done!");
		

		} finally {
			factory.close();
		}


	}

	private static void displayUsers(List<InternalUser> users) {
		// display students
		for (InternalUser user : users) {
			System.out.println(
					user.getFirstName() + "\t" + user.getLastName() + "\t" + user.getEmail() + "\t" + user.getId()+"\t" + user.isActivated());
		}
	}

	private static void displayStudents(List<Student> students) {
		// display students
		for (Student student : students) {
			
			System.out.println(
					 student.getId() + "\t" + student.getDeparture() + "\t" + student.getAccessYear() + "\t"
					+ student.getStudentsIncome() + "\t" + student.getFamilyIncome() + "\t"
					+ student.getParentsEmployement() + "\t" + student.getUser() + "\t" + student.getSiblings()
					+ "\t" + student.getCity());
		}
	}

}
