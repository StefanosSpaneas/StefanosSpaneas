package my.db;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import my.intranet.InternalUser;
import my.intranet.Student;

public class Update {

	public static void main(String[] args) {
		// works for internal user ONLY
		// create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(InternalUser.class).buildSessionFactory();

		// create session
		Session session = factory.getCurrentSession();

		// needs a scanner to enter the id
		try {
			int employeeId = 1;

			session = factory.getCurrentSession();
			// start a transaction
			session.beginTransaction();

			// retrieve user with id = 1
			System.out.println("retrieving internal_user with id = 1");
			InternalUser user = session.get(InternalUser.class, employeeId);

			// update internal user email
			System.out.println("updating student email");
			user.set�mail("haba.gr");

			// commit transaction
			session.getTransaction().commit();

			session = factory.getCurrentSession();
			session.beginTransaction();

			// update email for user with lastName='haba'
			session.createQuery("update internal_users set mail='hibi@hua.gr' where lastName='haba'").executeUpdate();

			session.getTransaction().commit();

			System.out.println("Done!");

		} finally {
			factory.close();
		}

	}
}
