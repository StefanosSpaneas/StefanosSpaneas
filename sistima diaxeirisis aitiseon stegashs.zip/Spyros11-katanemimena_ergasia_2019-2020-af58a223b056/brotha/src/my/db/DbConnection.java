package my.db;

import java.sql.Array;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import my.intranet.InternalUser;
import my.intranet.Student;
import my.settings.ReturnMessages;
import my.settings.Strings;

public class DbConnection {

	static Connection con = null;
	static PreparedStatement create = null;
	static PreparedStatement post = null;
	static ResultSet mrs = null;
	public static Scanner scanner = new Scanner(System.in);

	static String a, b, d, e;
	static int c, i;

	static int input;

	static ArrayList<InternalUser> guest = new ArrayList<InternalUser>();
	static ArrayList<Student> students = new ArrayList<Student>();
	static ArrayList<String> columns = new ArrayList<String>();

	static InternalUser user = new InternalUser("", "", 0, "", false);
	static Student student = new Student(a, a, c, a, true, c, c, c, true, c, c, true);
	
	static ReturnMessages msg = new ReturnMessages();
	static Strings strings = new Strings();

	static GeneratePassword pass = new GeneratePassword();

	static boolean activated;
	static boolean parentsEmp, cit;

	public static void main(String[] args) {
		// getConnection();
		 createTable();
		 //dropTable("internal_users");			
		 //insertUser("internal_users", "s","k", 23,"HEROCKS", 0); // works
		// columns = showColumns("internal_users"); // needs modificatons
		//createPassTable("passes");
		// checkEntry("internal_users", 214); // needs modifications
		//viewAll("students"); // like a candy
		//createPointsTable("points");
		 //deleteEntry("points", 212);
		// insertStudent("students", 214, 1, 2020, 202020, 0, 202020, 2, 1);
		//findRank("points");
		//String password = pass.generatePassword(5);
		//System.out.println(password);
		
	}

	public static Connection getConnection() {

		System.out.println("-------- Oracle JDBC Connection Testing ------");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
		}

		System.out.println("Oracle JDBC Driver Registered!");
		try {
			con = DriverManager.getConnection("jdbc:mysql://83.212.105.20:3306/it21575?useSSL=false", "it21575",
					"changeit");
		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
		}
		if (con != null) {
			System.out.println("You made it, take control your database now!");
			System.out.println("------------------\n");
		} else {
			System.out.println("Failed to make connection!");
		}
		return null;
	}

	// change it with more inputs!!
	public static void createTable() {
		System.out.println("Wanna create table for 1)internal user 2)student 3)employee(type 0 to exit)\n");
		do {
			try {
				input = Integer.parseInt(scanner.next());
				getConnection();
				if (input == 1) {
					create = con.prepareStatement("CREATE TABLE IF NOT EXISTS internal_users"
							+ "(firstName varchar(255), lastName varchar(255), id int NOT NULL AUTO_INCREMENT, mail varchar(255), isActivated int, PRIMARY KEY (id))");
					create.executeUpdate();

					msg.functionComplete();
					con.close();
				} else if (input == 2) {
					
					/*
					create = con.prepareStatement("CREATE TABLE IF NOT EXISTS students" + 
							"(id int(11) NOT NULL AUTO_INCREMENT," + 
							" firstName varchar(45) DEFAULT NULL," + 
							" lastName varchar(45) DEFAULT NULL," + 
							" email varchar(45) DEFAULT NULL," + 
							" isActivated int(1)," +
							" departure int(11) DEFAULT NULL," + 
							" accessYear double(5,2) DEFAULT NULL," + 
							" studentsIncome double(5,2) DEFAULT NULL," + 
							" parentsEmployment int(1)," + 
							" familyIncome double(5,2) DEFAULT NULL," + 
							" siblings int(11) DEFAULT NULL," + 
							" city int(1)," + 
							" internalUsersId int(11) DEFAULT NULL," + 
							" PRIMARY KEY (id)," + 
							"KEY FK_DETAIL_idy (internalUsersId)," + 							
							"CONSTRAINT FK_DETAILy FOREIGN KEY (internalUsersId) REFERENCES internal_users (id) ON DELETE NO ACTION ON UPDATE NO ACTION " + 
							") ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;");
					
					 */
					create = con.prepareStatement("CREATE TABLE IF NOT EXISTS students" + 
							"(id int(11) NOT NULL AUTO_INCREMENT," + 
							" departure int(11) DEFAULT NULL," + 
							" accessYear double(5,2) DEFAULT NULL," + 
							" studentsIncome double(5,2) DEFAULT NULL," + 
							" parentsEmployment int(1) DEFAULT NULL," + 
							" familyIncome double(5,2) DEFAULT NULL," + 
							" siblings int(11) DEFAULT NULL," + 
							" city int(1) DEFAULT NULL," + 
							" internalUsersId int(11) DEFAULT NULL UNIQUE," + 
							" PRIMARY KEY (id)," + 
							"KEY FK_DETAIL_idy (internalUsersId)," + 							
							"CONSTRAINT FK_DETAILy FOREIGN KEY (internalUsersId) REFERENCES internal_users (id) ON DELETE NO ACTION ON UPDATE NO ACTION " + 
							") ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;");
					
					create.executeUpdate();

					msg.functionComplete();
					con.close();
				} else if (input == 3) {
					create = con.prepareStatement("CREATE TABLE IF NOT EXISTS employees " +
							"(id int(11) NOT NULL AUTO_INCREMENT," + 
							" firstName varchar(45) DEFAULT NULL," + 
							" lastName varchar(45) DEFAULT NULL," + 
							" email varchar(45) DEFAULT NULL," + 
							" isActivated int DEFAULT NULL," +
							" internalUsersId int(11) DEFAULT NULL," + 
							" PRIMARY KEY (id), " +
							"KEY 'FK_DETAIL_id' ('internalUsersId'), " +
							"CONSTRAINT FK_DETAIL FOREIGN KEY (internalUsersId) REFERENCES internal_users (id) ON DELETE NO ACTION ON UPDATE NO ACTION" + 
							") ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;");

							
					create.executeUpdate();

					msg.functionComplete();
					con.close();
				}
			} catch (Exception e) {
				msg.fail();
				System.out.println(e);
				createTable();
			}
		} while (input != 0);

	}

	public static void createPointsTable(String tableName) {
		try {
			getConnection();
			create = con.prepareStatement("CREATE TABLE IF NOT EXISTS " + tableName
					+ "(id int NOT NULL AUTO_INCREMENT, points int, ranking int unique, PRIMARY KEY (id))");
			create.executeUpdate();

			msg.functionComplete();
			con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public static void createPassTable(String tableName) {
		try {
			getConnection();
			create = con.prepareStatement("CREATE TABLE " + tableName
					+ "(id int NOT NULL AUTO_INCREMENT, password varchar(255), PRIMARY KEY (id))");
			create.executeUpdate();

			msg.functionComplete();
			con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public static void insertUser(String tableName, String firstName, String lastName, int id, String mail,
			int isActivated) {

		try {
			getConnection();
			post = con.prepareStatement(
					"INSERT INTO " + tableName + " (firstName, lastName, id, mail, isActivated) VALUES ('" + firstName
							+ "', '" + lastName + "', '" + id + "', '" + mail + "', '" + isActivated + "')");
			post.executeUpdate();
			msg.success();
			con.close();
		} catch (Exception e) {
			msg.fail();
			System.out.println(e);
		}
	}

	public static void insertStudent(String tableName, int id, int departure, double accessYear, double studentsIncome, int parentsEmployment, double familyIncome, int siblings, int city) {
		try {
			getConnection();
			post = con.prepareStatement("INSERT INTO " + tableName
					+ " (id, departure, accessYear, studentsIncome, parentsEmployment, familyIncome, siblings, city) VALUES ('"
					+ id + "', '" + departure + "', '" + accessYear + "', '" + studentsIncome + "', '"
					+ parentsEmployment + "', '" + familyIncome + "', '" + siblings + "', '" + city + "')");
			post.executeUpdate();
			msg.success();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
			msg.fail();
		}
	}

	public static void insertPoints(String tableName, int points, int id, int rank) {
		try {
			// rank needs to be unique
			getConnection();
			post = con.prepareStatement("INSERT INTO " + tableName
					+ " (id, points, ranking) VALUES ('"
					+ id + "', '" + points +"', '" +rank+ "')");
			post.executeUpdate();
			msg.success();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
			msg.fail();
		}
	}
	
	// works on all tables!
	public static ArrayList<String> showColumns(String tableName) {
		try {
			getConnection();

			PreparedStatement stm = con.prepareStatement("SELECT * FROM " + tableName);
			ResultSetMetaData rsmd = stm.getMetaData();

			for (i = 1; i <= rsmd.getColumnCount(); i++) {
				String name = rsmd.getColumnName(i);
				columns.add(name);
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return columns;
	}

	public static void findRank(String tableName) {
		try {
			columns = showColumns(tableName);
			// make pointer to tail
			PreparedStatement stm = con.prepareStatement("SELECT * FROM " + tableName);
			ResultSet result = stm.executeQuery();
			while(result.next()) {
				int max = Integer.parseInt(result.getString(columns.get(2)));
				System.out.println(max);
			}
		}catch (Exception e) {
			System.out.println(e);
		}
	}
	
	static Student st = new Student();
	static List<Student> stud = null;
	static int y=0;
	static String array[] = new String[10];
	
	// works on all tables!
	public static List<Student> viewAll(String tableName) {
		try {
			columns = showColumns(tableName);
			
			PreparedStatement stm = con.prepareStatement("SELECT * FROM " + tableName);
			ResultSet result = stm.executeQuery();
			
			while(result.next()) {
				for(int i=0; i<columns.size(); i++) {
					/*
					y=1;
					st.setId(Integer.parseInt(result.getString(columns.get(0))));
					st.setDeparture(Integer.parseInt(result.getString(columns.get(1))));
					st.setAccessYear(Double.parseDouble(result.getString(columns.get(2))));
					st.setStudentsIncome(Double.parseDouble(result.getString(columns.get(3))));
					st.setParentsEmployement(Boolean.parseBoolean(result.getString(columns.get(4))));
					st.setFamilyIncome(Double.parseDouble(result.getString(columns.get(5))));
					st.setSiblings(Integer.parseInt(result.getString(columns.get(6))));
					st.setCity(Boolean.parseBoolean(result.getString(columns.get(7))));
					//st.setUser();
					*/
					System.out.printf(result.getString(columns.get(i)) +"\t");	
				}
				System.out.println("");
				}			
		}catch(Exception e) {
			System.out.println(e);
		}
		return stud;
	}
	
	public static Student viewStudent(String tableName) {
		try {
			columns = showColumns(tableName);
			
			PreparedStatement stm = con.prepareStatement("SELECT * FROM " + tableName);
			ResultSet result = stm.executeQuery();
			while(result.next()) {
				for(int i=0; i<columns.size(); i++) {
					st.setId(Integer.parseInt(result.getString(columns.get(0))));
					st.setDeparture(Integer.parseInt(result.getString(columns.get(1))));
					st.setAccessYear(Double.parseDouble(result.getString(columns.get(2))));
					st.setStudentsIncome(Double.parseDouble(result.getString(columns.get(3))));
					st.setParentsEmployement(Boolean.parseBoolean(result.getString(columns.get(4))));
					st.setFamilyIncome(Double.parseDouble(result.getString(columns.get(5))));
					st.setSiblings(Integer.parseInt(result.getString(columns.get(6))));
					st.setCity(Boolean.parseBoolean(result.getString(columns.get(7))));
					//st.setUser();
					
					System.out.printf(result.getString(columns.get(i)) +"\t");
				}
				System.out.println("");
			}
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
		return st;
	}
	
	public static InternalUser checkEntry(String tableName, int id) {
		try {
			getConnection();

			PreparedStatement stm = con.prepareStatement("SELECT * FROM " + tableName);
			ResultSet result = stm.executeQuery();
			while (result.next()) {
				if (Integer.parseInt(result.getString("id")) == id) {
					user.setFirstName(result.getString("firstName"));
					user.setLastName(result.getString("lastName"));
					user.setId(Integer.parseInt(result.getString("id")));
					user.set�mail(result.getString("mail"));
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return user;
	}
	
	public static Student checkStudentEntry(String tableName, int id) {
		try {
			getConnection();

			PreparedStatement stm = con.prepareStatement("SELECT * FROM " + tableName);
			ResultSet result = stm.executeQuery();
			while (result.next()) {
				if(result.getString("parentsEmployment").equals("0")) {
					parentsEmp = false;
				}else {
					parentsEmp = true;
				}
				if(result.getString("city").equals("0")) {
					cit = false;
				}else {
					cit = true;
				}
				if (Integer.parseInt(result.getString("id")) == id) {
					student.setAccessYear(Double.parseDouble(result.getString("accessYear")));
					student.setCity(cit);
					student.setDeparture(Integer.parseInt(result.getString("departure")));
					student.setFamilyIncome(Double.parseDouble(result.getString("familyIncome")));
					student.setParentsEmployement(parentsEmp);
					student.setSiblings(Integer.parseInt(result.getString("siblings")));
					student.setStudentsIncome(Double.parseDouble(result.getString("studentsIncome")));
					student.setId(Integer.parseInt(result.getString("id")));
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return student;
	}

	public static void deleteEntry(String tableName, int id) {
		try {
			getConnection();

			PreparedStatement stm = con.prepareStatement("DELETE FROM " + tableName + " WHERE id = " + id);
			stm.executeUpdate();
			msg.success();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void setActivated(String tableName, int id, boolean isActivated) {
		try {
			getConnection();

			PreparedStatement stm = con.prepareStatement(
					"UPDATE " + tableName + " SET isActivated = " + isActivated + " WHERE id = " + id);
			stm.executeUpdate();
			msg.success();

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public static void dropTable(String tableName) {
		try {
			getConnection();

			PreparedStatement stm = con.prepareStatement("DROP TABLE " + tableName);
			stm.executeUpdate();
			msg.success();

		} catch (Exception e) {
			System.out.println(e);
		}
	}
	

}
