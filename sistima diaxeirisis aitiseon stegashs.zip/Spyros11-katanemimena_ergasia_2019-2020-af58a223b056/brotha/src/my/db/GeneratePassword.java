package my.db;

import java.security.SecureRandom;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
 
public class GeneratePassword {
    private static final Random RANDOM = new SecureRandom();
    private static final String ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    public static void main(String[] args) {
        // Define desired password length
        int passwordLength = 10;
        
        // Generate Secure Password
        String password = generatePassword(passwordLength);
        
        // Print out password value
        System.out.println("Secure password: " + password);
    
        String key = "theAzoRes#";
        try {
			String answer = encrypt(password,key);
			
			System.out.println("Encrypted password: " +answer);
			String answer1 = decrypt(answer,key);
			
			System.out.println("Decrypted password: " +answer1);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
    public static String generatePassword(int length) {
        StringBuilder returnValue = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            returnValue.append(ALPHABET.charAt(RANDOM.nextInt(ALPHABET.length())));
        }
        return new String(returnValue);
    }
    
    public static String encrypt(String strClearText,String strKey) throws Exception{
    	String strData="";
    	
    	try {
    		SecretKeySpec skeyspec=new SecretKeySpec(strKey.getBytes(),"Blowfish");
    		Cipher cipher=Cipher.getInstance("Blowfish");
    		cipher.init(Cipher.ENCRYPT_MODE, skeyspec);
    		byte[] encrypted=cipher.doFinal(strClearText.getBytes());
    		strData=new String(encrypted);
    		
    	} catch (Exception e) {
    		e.printStackTrace();
    		throw new Exception(e);
    	}
    	return strData;
    }
    
    public static String decrypt(String strEncrypted,String strKey) throws Exception{
    	String strData="";
    	
    	try {
    		SecretKeySpec skeyspec=new SecretKeySpec(strKey.getBytes(),"Blowfish");
    		Cipher cipher=Cipher.getInstance("Blowfish");
    		cipher.init(Cipher.DECRYPT_MODE, skeyspec);
    		byte[] decrypted=cipher.doFinal(strEncrypted.getBytes());
    		strData=new String(decrypted);
    		
    	} catch (Exception e) {
    		e.printStackTrace();
    		throw new Exception(e);
    	}
    	return strData;
    }

}