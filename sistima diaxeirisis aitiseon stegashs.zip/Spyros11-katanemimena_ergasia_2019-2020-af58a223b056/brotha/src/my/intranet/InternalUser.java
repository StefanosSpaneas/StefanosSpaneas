package my.intranet;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity(name="internal_users")
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name="internal_users")
public class InternalUser {
	
	@Column(name="firstName")
	private String firstName;
	
	@Column(name="lastName")	
	private String lastName;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="mail")	
	private String mail;
	
	@Column(name="isActivated")	
	private boolean isActivated;
	
	//Constructor of InternalUser
	public InternalUser(String firstName, String lastName, int id, String mail, boolean isActivated) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.id = id ;
		this.mail = mail;
		this.isActivated = isActivated;
	}
	
	public InternalUser() {
		
	}
	//set get
	public String getFirstName() {
		return firstName;
	}
	
	public void  setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void  setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public int getId() {
		return id;
	}
	
	public void  setId(int id) {
		this.id = id;
	}
	
	public String getEmail() {
		return mail;
	}
	
	public void  set�mail(String mail) {
		this.mail = mail;
	}

	public boolean isActivated() {
		return isActivated;
	}

	public void setActivated(boolean isActivated) {
		this.isActivated = isActivated;
	}
	
	
}
