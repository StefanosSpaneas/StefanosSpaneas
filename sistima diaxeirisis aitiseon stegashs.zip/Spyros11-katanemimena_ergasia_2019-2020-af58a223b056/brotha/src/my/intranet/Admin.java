package my.intranet;

public class Admin extends InternalUser {

	private String lastName;
	
	public Admin (String name, String lastname, int userId, String mail, boolean isActivated) {
		super(name, lastname, userId, mail, isActivated);
		
	}
	
	/*public String getlastName() {
		return lastName;
		}
	public void  setlastName(String newlName) {
		this.firstName = newlName;
		}
	*/
	
	//methodoi
	
	public void dbOperate() {
		// to be made later
	}
    

}
