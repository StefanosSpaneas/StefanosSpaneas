package my.intranet;

import my.db.DbConnection;
import my.settings.Strings;

public class Run {

	public static void main(String[] args) {


	DbConnection db = new DbConnection();
	Employee e1 = new Employee("","", 0, "", true,0);
	InternalUser u1 = new Student("s", "k", 1, "mail",false, 2, 1997, 21.1, true, 31.1, 3, false);
	InternalUser u2 = new InternalUser("haba", "haba", 2, "hibi",true);
	Strings strings = new Strings();
	
	db.getConnection();
	//int points = e1.rateStudentCriteria(212, true, 5, true, 555, 2, 0, true);
	//db.insertPoints("points", points, 212, 2);
	//s1.changeContactInfo(s1);	
	//boolean answer = Strings.checkMail("haba@haba.gr");
	//System.out.println(answer);
	//e1.activateStudent("internal_users", 214);
	}
}
