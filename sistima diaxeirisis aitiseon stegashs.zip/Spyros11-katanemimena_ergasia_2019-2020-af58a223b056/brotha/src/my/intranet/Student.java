package my.intranet;

import java.util.Scanner;

import java.util.regex.Pattern;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import my.db.DbConnection;
import my.settings.ReturnMessages;
import my.settings.Strings;

@Entity(name="students")
@Table(name="students")
@PrimaryKeyJoinColumn(name="id")  

public class Student extends InternalUser {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="departure")
	private int departure;
	
	@Column(name="accessYear")
	private double accessYear;
	
	@Column(name="studentsIncome")
	private double studentsIncome;
	
	@Column(name="parentsEmployment")
	private boolean parentsEmployment;
	
	@Column(name="familyIncome")
	private double familyIncome;
	
	@Column(name="siblings")
	private int siblings;
	
	@Column(name="city")
	private boolean city;

    @OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="internalUsersId")
    private InternalUser user;
    
	//private int internalUsersId;
	
	//private int employeesId;
	
	public Student (String name, String lastname, int id, String mail, boolean isActivated, int departure, double accessYear, double studentsIncome, boolean parentsEmployment,
			double familyIncome, int siblings, boolean city) {
		
		super(name, lastname, id, mail, isActivated);
		this.departure = departure;
		this.accessYear  = accessYear;
		this.studentsIncome = studentsIncome;
		this.parentsEmployment = parentsEmployment;
		this.familyIncome = familyIncome;
		this.siblings = siblings;
		this.city = city;
	}
	
	public Student() {
		
	}
	
	//me8odoi : changeContactInfo (completed) view=Rank(db)  resultOfRequest
	// to be checked: residenceRequest
	//set get gia ta kainouria mono 
	//an 8elw na xrismopoihsw kati tis InternalUser tote grafw super.kati ktl,....
	public int getDeparture() {
		return departure;
	}
	
	public void  setDeparture(int newdep) {
		this.departure = newdep;
	}
	
	public double getAccessYear() {
		return accessYear;
	}
	
	public void  setAccessYear(double newYear) {
		this.accessYear = newYear;
	}
	
	public double getStudentsIncome() {
		return studentsIncome;
	}
	
	public void  setStudentsIncome(double newstIncome) {
		this.studentsIncome = newstIncome;
	}
	
	public boolean getParentsEmployement() {
		return parentsEmployment;
	}
	
	public void setParentsEmployement(boolean newpEmpl) {
		this.parentsEmployment = newpEmpl;
	}
	
	public double getFamilyIncome() {
		return familyIncome;
	}
	public void  setFamilyIncome(double newfIncome) {
		this.familyIncome = newfIncome;
	}
	
	public int getSiblings() {
		return siblings;
	}
	
	public void setSiblings(int newsbl) {
		this.siblings = newsbl;
	}
	
	public boolean getCity() {
		return city;
	}
	
	public void  setCity(boolean newCity) {
		this.city = newCity;
	}

	public InternalUser getUser() {
		return user;
	}

	public void setUser(InternalUser user) {
		this.user = user;
	}
	
	
	/*
	public int getEmployeesId() {
		return employeesId;
	}

	public void setEmployeesId(int employeesId) {
		this.employeesId = employeesId;
	}
*/

	/*
	public Scanner scanner = new Scanner(System.in);
	private boolean proceed = false;
	private String choice, temp_mail;
	
	static ReturnMessages mes = new ReturnMessages();
	static Strings strings = new Strings();
	static DbConnection con = new DbConnection();
	static InternalUser user = new InternalUser("","",1,"", true);
	
	public void changeContactInfo(Student s) {
		// finished!
		System.out.println("_____hello mate_____\nWould u like to change your email contact ? ");
		do {
		System.out.println("Press Y or N(To exit press 0)\n\n");
			choice = scanner.nextLine();
			if(choice.contentEquals("0"))
				return;
			proceed = strings.checkString(choice);	
			
		}while(proceed == false);
		
		do {
			System.out.println("Please type the email you want to be changed\n");
			temp_mail = scanner.nextLine();
			if (temp_mail.equals(s.getEmail()))
				System.out.println("U FUCKIN STUPID?\n");
			
			System.out.println("The email : " +s.getEmail() +" will be changed to: " +temp_mail +"\nAre you sure about that?\nPress Y or N(To exit press 0)\n\n");
			
			do {
				
				choice = scanner.nextLine();
				if(choice.contentEquals("0"))
					return;
				proceed = strings.checkString(choice);
				
			}while(proceed == false);
			
			boolean answer = strings.checkMail(temp_mail);
			if(answer == true) {
				mes.success();
				proceed = true;
			} else {
				mes.fail();
				proceed = false;
				// go back
			}
		} while (proceed == false);
		
		s.set�mail(temp_mail);		// to be checked via method
			
	}
	
	public static void residenceRequest(int id) {
		user = con.checkEntry("internal_users", id);
		if(user == null) {
			mes.fail();
			return;
		}
		if (user.isActivated() == false) {
			mes.isNotActivated();
			return;
		}
		// change to db residence request status!!!!	
	}
	
	public static void viewRank(String tableName, int id) {
		// create new table with queue number
	}
	*/
	
}
