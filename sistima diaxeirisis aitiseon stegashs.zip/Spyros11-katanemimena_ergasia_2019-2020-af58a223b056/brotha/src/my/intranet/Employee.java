package my.intranet;

import my.db.DbConnection;
import my.settings.ReturnMessages;

public class Employee extends InternalUser {
	private int department;
	
	static DbConnection db = new DbConnection();
	static InternalUser user = new InternalUser("","",0,"", true);
	static ReturnMessages mes = new ReturnMessages();
	static DbConnection con = new DbConnection();
	//methodoi:  evaluateStatement
	// to be checked: activateStudent rateStudentCriteria  
	
	public Employee(String name, String lastname, int id, String mail, boolean isActivated, int department) {
		super(name, lastname, id, mail, isActivated);
		this.department =  department;	
	}
	
	public int get�mployeeDeparture() {
		return department;
		}
	
	public void  set�mployeeDeparture(int employeeDepartment) {
		this.department = employeeDepartment;
		}
	
	public static void activateStudent(String tableName, int id) {
		user = db.checkEntry(tableName, id);
		if(user == null) {
			mes.fail();
			return;
		}
		
		if(user.isActivated() == true) {
			mes.isActivated();
			return;
		} else {
			con.setActivated(tableName, id, true);
		}
	}
	
	public static void viewStudentDocumentation(String tableName, int id) {
		// new table with familyIncome etc
		db.checkStudentEntry(tableName, id);
		
	}
	
	public static boolean evaluateStatement(boolean city, double accessYear) {
		boolean valid = false;
		
		if(city == true && (2020 - accessYear) < 4) {
			valid = true;
		}
		
		
		return valid;		
	}
	
	
	
	public static int rateStudentCriteria(int id, boolean isActivated, double studentsIncome, boolean parentsEmployment, double familyIncome, int siblings, int freeHousingYears, boolean city) {
		int points = 0;
		if(isActivated == false) {
			mes.isNotActivated();
			System.exit(0);
		}
		if (parentsEmployment == false) {
			mes.freeHousing();
			// create table with MUST HOUSE students
		} 
		if (familyIncome < 10000) {
			points += 100;
		}
		else if(familyIncome > 10000 && familyIncome < 15000) {
			points += 30;
		}
		if(siblings > 0) {
			points += (siblings *20);
		}
		if(city == true) {
			points += 50;
		}
		
		if(freeHousingYears > 0) {
			points -= freeHousingYears*10;
		}
		return points;
	}
	

}
