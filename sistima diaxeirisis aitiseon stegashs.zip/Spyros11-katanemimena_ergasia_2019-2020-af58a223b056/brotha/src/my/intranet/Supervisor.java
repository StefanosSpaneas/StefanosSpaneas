package my.intranet;

public class Supervisor extends Employee {



	public Supervisor(String name, String lastname, int userId, String mail, boolean isActivated, int employeeDepartment) {
	super(name, lastname, userId, mail, isActivated, employeeDepartment);

	}
	
	public void updateStatus() {
		
	}

}