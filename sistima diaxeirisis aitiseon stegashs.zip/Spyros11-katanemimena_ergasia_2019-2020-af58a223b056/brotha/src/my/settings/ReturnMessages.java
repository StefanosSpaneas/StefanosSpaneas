package my.settings;

public class ReturnMessages {

	public void success() {
		System.out.println("SUCCESS\n");
	}
	
	public void fail() {
		System.out.println("U MOTHER....\n");
	}
	
	public void again() {
		System.out.println("TRY AGAIN U BIATCH\n");
	}
	
	public void isActivated() {
		System.out.println("The user is activated\n");		
	}
	
	public void isNotActivated() {
		System.out.println("The user is not activated\n");		
	}
	
	public void freeHousing() {
		System.out.println("You will be given full housing\n");		
	}
	
	public void functionComplete() {
		System.out.println("FUNCTION COMPLETE \n");
	}
}
