package my.settings;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Strings {
	ReturnMessages mes = new ReturnMessages();
	Scanner input = new Scanner(System.in);
	
	boolean isNumber;

	public static boolean checkMail(String email) { 
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                            "[a-zA-Z0-9_+&*-]+)*@" + 
                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                            "A-Z]{2,7}$"; 
                              
        Pattern pat = Pattern.compile(emailRegex); 
        if (email == null) 
            return false; 
        return pat.matcher(email).matches(); 
    }
	
	public boolean checkString(String test) {
		if(test.startsWith("Y") || test.startsWith("y")) {
			//System.out.println("HOORAY");		// TO BE EDITED!!!!
			mes.success();
			return true;
		}else if (test.startsWith("N") || test.startsWith("n")) {
			//System.out.println("FUNK YOU");		// TO BE EDITED!!!!
			mes.fail();
			System.exit(1);
			return false;
		}else {
			mes.again();	// TO BE EDITED!!!!
			return false;
		}
	}
	
	public boolean checkInt(int number) {
		do {
			if(input.hasNextInt()) {
				number = input.nextInt();
				isNumber = true;
			}else {
				mes.fail();
				isNumber = false;
				//input.next();
			}
		}while(!(isNumber));
		System.out.println(number);
		return true;
	}
}
